# Auto Clicker / Tecla

Aplicativo Windows com modo **básico** e **avançado**.

## Modo básico

Uma ação por vez: teclado ou mouse, loop ou segurar, atalho configurável.

## Modo avançado

- Vários painéis (numerados 1, 2, 3… na ordem atual)
- Cada painel: teclado/mouse, loop/segurar, tempos próprios
- **Destacar / arrastar ◧**: abre o painel numa janela separada
- **Anexar** (ou fechar a janela): volta o painel para o programa
- Controles de tamanho da janela principal

## Save automático

As configurações (básico, avançado, painéis, atalho, janelas destacadas) são salvas em `config.json` e restauradas ao abrir de novo.

## Como abrir

Duplo clique em `iniciar.bat`
