"""
Auto Clicker / Tecla Automática
Modo básico (uma ação) e modo avançado (várias ações independentes).
"""

from __future__ import annotations

import ctypes
import json
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, simpledialog
from typing import Any, Callable

from pynput.keyboard import Controller as KeyboardController
from pynput.keyboard import Key, KeyCode, Listener as KeyboardListener
from pynput.mouse import Button, Controller as MouseController
from pynput.mouse import Listener as MouseListener


keyboard = KeyboardController()
mouse = MouseController()
CONFIG_PATH = Path(__file__).resolve().parent / "config.json"
RECORDINGS_DIR = Path(__file__).resolve().parent / "recordings"
COMBOS_DIR = Path(__file__).resolve().parent / "combos"

# DPI awareness for accurate mouse positioning
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except:
        pass

# Theme definitions
THEMES = {
    "dark": {
        "bg": "#1a1d23",
        "fg": "#e8eaed",
        "card_bg": "#1e232b",
        "card_fg": "#e8eaed",
        "accent": "#4a9eff",
        "input_bg": "#2a2e36",
        "input_fg": "#e8eaed"
    },
    "light": {
        "bg": "#ffffff",
        "fg": "#1a1d23",
        "card_bg": "#f5f5f5",
        "card_fg": "#1a1d23",
        "accent": "#4a9eff",
        "input_bg": "#e0e0e0",
        "input_fg": "#1a1d23"
    },
    "night": {
        "bg": "#0a0e1a",
        "fg": "#e8eaed",
        "card_bg": "#0f1425",
        "card_fg": "#e8eaed",
        "accent": "#4a9eff",
        "input_bg": "#1a1f35",
        "input_fg": "#e8eaed"
    },
    "red": {
        "bg": "#1a0a0a",
        "fg": "#e8eaed",
        "card_bg": "#1f0f0f",
        "card_fg": "#e8eaed",
        "accent": "#ff4a4a",
        "input_bg": "#2a1515",
        "input_fg": "#e8eaed"
    },
    "aurora": {
        "bg": "#0a1a1a",
        "fg": "#e8eaed",
        "card_bg": "#0f1f1f",
        "card_fg": "#e8eaed",
        "accent": "#4aff9e",
        "input_bg": "#1a2a2a",
        "input_fg": "#e8eaed"
    },
    "hell": {
        "bg": "#1a0505",
        "fg": "#ffaa88",
        "card_bg": "#1f0808",
        "card_fg": "#ffaa88",
        "accent": "#ff4a4a",
        "input_bg": "#2a0a0a",
        "input_fg": "#ffaa88"
    }
}

# Language translations
TRANSLATIONS = {
    "pt": {
        "basic": "Básico",
        "advanced": "Avançado",
        "recording": "Gravar/Reproduzir",
        "settings": "Configurações",
        "language": "Idioma",
        "theme": "Tema",
        "save": "Salvar",
        "load": "Carregar",
        "delete": "Deletar",
        "combo": "Combo",
        "record": "Gravar",
        "play": "Reproduzir",
        "stop": "Parar",
        "hotkey": "Hotkey",
        "interval": "Intervalo",
        "action": "Ação",
        "loop": "Loop",
        "hold": "Segurar",
        "mouse": "Mouse",
        "keyboard": "Teclado",
        "left": "Esquerdo",
        "right": "Direito",
        "middle": "Meio",
        "start": "Iniciar",
        "capture": "Capturar",
        "capture_hotkey": "Capturar atalho",
        "capture_key": "Capturar tecla",
        "input_type": "Tipo de entrada",
        "action_mode": "Modo de ação",
        "button": "Botão",
        "interval_ms": "Intervalo entre ações (ms)",
        "press_ms": "Tempo pressionado por clique (ms)",
        "global_hotkey": "Atalho iniciar / parar",
        "start_all": "Iniciar todas",
        "stop_all": "Parar todas",
        "add_panel": "+ Adicionar painel (tecla/mouse)",
        "window": "Janela",
        "width": "Largura",
        "height": "Altura",
        "apply_size": "Aplicar tamanho",
        "maximize": "Maximizar",
        "restore": "Restaurar",
        "fullscreen": "Tela cheia (F11)",
        "no_combo_saved": "Nenhum combo salvo",
        "save_current_combo": "Salvar Combo Atual",
        "apply": "Aplicar",
        "portuguese": "Português",
        "english": "English",
        "drag_hint": "Arraste ◧ para destacar · fechar a janela destacada remove o painel · Anexar volta na ordem",
        "recording_hotkeys": "Atalhos de Gravação/Reprodução",
        "record_hotkey": "Gravar:",
        "playback_hotkey": "Reproduzir:",
        "recordings_list": "Gravações salvas",
        "save_recording": "Salvar gravação",
        "delete_recording": "Deletar gravação",
        "loop_playback": "Loop reprodução",
        "playback_speed": "Velocidade reprodução",
        "status_ready": "Pronto para gravar",
        "status_recording": "Gravando...",
        "status_playing": "Reproduzindo..."
    },
    "en": {
        "basic": "Basic",
        "advanced": "Advanced",
        "recording": "Record/Playback",
        "settings": "Settings",
        "language": "Language",
        "theme": "Theme",
        "save": "Save",
        "load": "Load",
        "delete": "Delete",
        "combo": "Combo",
        "record": "Record",
        "play": "Play",
        "stop": "Stop",
        "hotkey": "Hotkey",
        "interval": "Interval",
        "action": "Action",
        "loop": "Loop",
        "hold": "Hold",
        "mouse": "Mouse",
        "keyboard": "Keyboard",
        "left": "Left",
        "right": "Right",
        "middle": "Middle",
        "start": "Start",
        "capture": "Capture",
        "capture_hotkey": "Capture hotkey",
        "capture_key": "Capture key",
        "input_type": "Input type",
        "action_mode": "Action mode",
        "button": "Button",
        "interval_ms": "Interval between actions (ms)",
        "press_ms": "Press duration per click (ms)",
        "global_hotkey": "Global hotkey (start/stop ALL)",
        "start_all": "Start all",
        "stop_all": "Stop all",
        "add_panel": "+ Add panel (key/mouse)",
        "window": "Window",
        "width": "Width",
        "height": "Height",
        "apply_size": "Apply size",
        "maximize": "Maximize",
        "restore": "Restore",
        "fullscreen": "Fullscreen (F11)",
        "no_combo_saved": "No combo saved",
        "save_current_combo": "Save Current Combo",
        "apply": "Apply",
        "portuguese": "Portuguese",
        "english": "English",
        "drag_hint": "Drag ◧ to detach · closing detached window removes panel · Attach restores order",
        "recording_hotkeys": "Recording/Playback Hotkeys",
        "record_hotkey": "Record:",
        "playback_hotkey": "Playback:",
        "recordings_list": "Saved recordings",
        "save_recording": "Save recording",
        "delete_recording": "Delete recording",
        "loop_playback": "Loop playback",
        "playback_speed": "Playback speed",
        "status_ready": "Ready to record",
        "status_recording": "Recording...",
        "status_playing": "Playing..."
    }
}

RECORDINGS_DIR.mkdir(exist_ok=True)
COMBOS_DIR.mkdir(exist_ok=True)


def keys_equal(a, b) -> bool:
    if a is None or b is None:
        return False
    if a == b:
        return True
    if isinstance(a, KeyCode) and isinstance(b, KeyCode):
        if a.vk is not None and b.vk is not None and a.vk == b.vk:
            return True
        if a.char and b.char and a.char.lower() == b.char.lower():
            return True
    if isinstance(a, Button) and isinstance(b, Button):
        return a == b
    return False


def key_to_label(key) -> str:
    if isinstance(key, KeyCode) and key.char:
        return key.char.upper()
    if isinstance(key, Key):
        return key.name.upper().replace("_", " ")
    if isinstance(key, Button):
        return button_to_label(key)
    return str(key).replace("Key.", "").upper()


def button_to_label(button: Button) -> str:
    if button == Button.left:
        return "ESQUERDO"
    elif button == Button.right:
        return "DIREITO"
    elif button == Button.middle:
        return "MEIO"
    elif button == Button.x1:
        return "VOLTAR"
    elif button == Button.x2:
        return "AVANÇAR"
    return str(button).upper()


def serialize_key(key) -> dict | None:
    if key is None:
        return None
    if isinstance(key, Key):
        return {"type": "special", "name": key.name}
    if isinstance(key, KeyCode):
        data: dict[str, Any] = {"type": "code"}
        if key.vk is not None:
            data["vk"] = key.vk
        if key.char:
            data["char"] = key.char
        return data
    if isinstance(key, Button):
        return {"type": "button", "name": serialize_button(key)}
    return None


def deserialize_key(data: dict | None):
    if not data:
        return None
    try:
        if data.get("type") == "special":
            return getattr(Key, data["name"])
        if data.get("vk") is not None:
            return KeyCode.from_vk(int(data["vk"]))
        if data.get("char"):
            char = str(data["char"])
            return KeyCode.from_char(char)
        if data.get("type") == "button":
            return deserialize_button(data["name"])
    except Exception:
        return None
    return None


def serialize_button(button: Button) -> str:
    if button == Button.left:
        return "left"
    elif button == Button.right:
        return "right"
    elif button == Button.middle:
        return "middle"
    elif button == Button.x1:
        return "x1"
    elif button == Button.x2:
        return "x2"
    return "left"


def deserialize_button(name: str) -> Button:
    if name == "right":
        return Button.right
    elif name == "middle":
        return Button.middle
    elif name == "x1":
        return Button.x1
    elif name == "x2":
        return Button.x2
    return Button.left


class RecordingManager:
    def __init__(self):
        self.recording = False
        self.playing = False
        self.events = []
        self.start_time = None
        self.playback_thread = None
        self.stop_event = threading.Event()
        self.keyboard_listener = None
        self.mouse_listener = None

    def start_recording(self):
        if self.recording or self.playing:
            return False
        self.recording = True
        self.events = []
        self.start_time = None
        self.stop_event.clear()
        
        def on_key_press(key):
            if not self.recording:
                return
            if self.start_time is None:
                self.start_time = time.time()
            self.events.append({
                "type": "key_press",
                "time": time.time() - self.start_time,
                "key": serialize_key(key)
            })

        def on_key_release(key):
            if not self.recording:
                return
            if self.start_time is None:
                self.start_time = time.time()
            self.events.append({
                "type": "key_release",
                "time": time.time() - self.start_time,
                "key": serialize_key(key)
            })

        def on_mouse_click(x, y, button, pressed):
            if not self.recording:
                return
            if self.start_time is None:
                self.start_time = time.time()
            self.events.append({
                "type": "mouse_click",
                "time": time.time() - self.start_time,
                "x": x,
                "y": y,
                "button": serialize_button(button),
                "pressed": pressed
            })

        def on_mouse_move(x, y):
            if not self.recording:
                return
            if self.start_time is None:
                self.start_time = time.time()
            self.events.append({
                "type": "mouse_move",
                "time": time.time() - self.start_time,
                "x": x,
                "y": y
            })

        def on_mouse_scroll(x, y, dx, dy):
            if not self.recording:
                return
            if self.start_time is None:
                self.start_time = time.time()
            self.events.append({
                "type": "mouse_scroll",
                "time": time.time() - self.start_time,
                "x": x,
                "y": y,
                "dx": dx,
                "dy": dy
            })

        self.keyboard_listener = KeyboardListener(
            on_press=on_key_press,
            on_release=on_key_release
        )
        self.mouse_listener = MouseListener(
            on_click=on_mouse_click,
            on_move=on_mouse_move,
            on_scroll=on_mouse_scroll
        )
        self.keyboard_listener.start()
        self.mouse_listener.start()
        return True

    def stop_recording(self):
        if not self.recording:
            return None
        self.recording = False
        if self.keyboard_listener:
            self.keyboard_listener.stop()
        if self.mouse_listener:
            self.mouse_listener.stop()
        return self.events

    def play_recording(self, events, on_complete=None, on_error=None, loop=False, speed=1.0):
        if self.playing or self.recording:
            return False
        if not events:
            return False
        
        self.playing = True
        self.stop_event.clear()
        
        def playback_worker():
            try:
                while True:
                    start_time = time.time()
                    for event in events:
                        if self.stop_event.is_set():
                            break
                        target_time = start_time + (event["time"] / speed)
                        current_time = time.time()
                        wait_time = target_time - current_time
                        if wait_time > 0:
                            if self.stop_event.wait(wait_time):
                                break
                        
                        if event["type"] == "key_press":
                            key = deserialize_key(event["key"])
                            if key:
                                keyboard.press(key)
                        elif event["type"] == "key_release":
                            key = deserialize_key(event["key"])
                            if key:
                                keyboard.release(key)
                        elif event["type"] == "mouse_click":
                            button = deserialize_button(event["button"])
                            if event["pressed"]:
                                mouse.press(button)
                            else:
                                mouse.release(button)
                        elif event["type"] == "mouse_move":
                            mouse.position = (event["x"], event["y"])
                        elif event["type"] == "mouse_scroll":
                            mouse.position = (event["x"], event["y"])
                            mouse.scroll(int(event["dx"]), int(event["dy"]))
                    
                    if self.stop_event.is_set():
                        break
                    
                    # If not loop, break after one iteration
                    if not loop:
                        break
            except Exception as e:
                if on_error:
                    on_error(str(e))
            finally:
                self.playing = False
                self.stop_event.set()
                if on_complete:
                    on_complete()
        
        self.playback_thread = threading.Thread(target=playback_worker, daemon=True)
        self.playback_thread.start()
        return True

    def stop_playback(self):
        self.stop_event.set()
        self.playing = False


import time


def parse_ms(raw: str, field_name: str, minimum: float = 1) -> float:
    try:
        ms = float(raw.replace(",", "."))
        if ms < minimum:
            raise ValueError
        return ms / 1000.0
    except ValueError as exc:
        raise ValueError(
            f"Informe um valor válido para {field_name} (mínimo {int(minimum)} ms)."
        ) from exc


def resolve_mouse_button(name: str) -> Button:
    return {
        "esquerdo": Button.left,
        "meio": Button.middle,
        "direito": Button.right,
    }[name]


class ActionRunner:
    def __init__(self) -> None:
        self.running = False
        self.stop_event = threading.Event()
        self.worker: threading.Thread | None = None
        self.held_key = None
        self.held_button = None

    def start(
        self,
        *,
        input_mode: str,
        action: str,
        key,
        mouse_btn: str,
        interval: float,
        press_duration: float,
        on_error: Callable[[str], None] | None = None,
        on_stopped: Callable[[], None] | None = None,
    ) -> None:
        if self.running:
            return
        self.running = True
        self.stop_event.clear()
        self.worker = threading.Thread(
            target=self._run,
            kwargs={
                "input_mode": input_mode,
                "action": action,
                "key": key,
                "mouse_btn": mouse_btn,
                "interval": interval,
                "press_duration": press_duration,
                "on_error": on_error,
                "on_stopped": on_stopped,
            },
            daemon=True,
        )
        self.worker.start()

    def stop(self) -> None:
        self.running = False
        self.stop_event.set()
        self._release_held()

    def _release_held(self) -> None:
        try:
            if self.held_key is not None:
                keyboard.release(self.held_key)
                self.held_key = None
            if self.held_button is not None:
                mouse.release(self.held_button)
                self.held_button = None
        except Exception:
            pass

    def _run(
        self,
        input_mode: str,
        action: str,
        key,
        mouse_btn: str,
        interval: float,
        press_duration: float,
        on_error,
        on_stopped,
    ) -> None:
        try:
            if action == "segurar":
                self._run_hold(input_mode, key, mouse_btn)
            else:
                self._run_repeat(input_mode, key, mouse_btn, interval, press_duration)
        except Exception as exc:
            if on_error:
                on_error(str(exc))
        finally:
            self._release_held()
            self.running = False
            if on_stopped:
                on_stopped()

    def _run_hold(self, input_mode: str, key, mouse_btn: str) -> None:
        if input_mode == "teclado":
            self.held_key = key
            while not self.stop_event.is_set():
                keyboard.press(self.held_key)
                if self.stop_event.wait(0.05):
                    break
        else:
            self.held_button = resolve_mouse_button(mouse_btn)
            while not self.stop_event.is_set():
                mouse.press(self.held_button)
                if self.stop_event.wait(0.05):
                    break

    def _run_repeat(
        self,
        input_mode: str,
        key,
        mouse_btn: str,
        interval: float,
        press_duration: float,
    ) -> None:
        while not self.stop_event.is_set():
            if input_mode == "teclado":
                self.held_key = key
                keyboard.press(self.held_key)
                if press_duration > 0 and self.stop_event.wait(press_duration):
                    keyboard.release(self.held_key)
                    self.held_key = None
                    break
                keyboard.release(self.held_key)
                self.held_key = None
            else:
                self.held_button = resolve_mouse_button(mouse_btn)
                mouse.press(self.held_button)
                if press_duration > 0 and self.stop_event.wait(press_duration):
                    mouse.release(self.held_button)
                    self.held_button = None
                    break
                mouse.release(self.held_button)
                self.held_button = None
            if self.stop_event.wait(interval):
                break


class AutoApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Auto Clicker / Tecla")
        self.root.minsize(420, 480)
        self.root.resizable(True, True)
        self.root.configure(bg="#1a1d23")

        self.view_mode = "basico"
        self._fullscreen = False
        self._geom_before_fullscreen: str | None = None
        self._shared_geom = "520x620"
        self._uid_counter = 0
        self._save_after_id: str | None = None
        self._loading = True

        self.hotkey: Key | KeyCode = Key.f6
        self.hotkey_display = tk.StringVar(value="F6")
        self.window_w = tk.StringVar(value="720")
        self.window_h = tk.StringVar(value="720")

        self.record_hotkey: Key | KeyCode = Key.f7
        self.record_hotkey_display = tk.StringVar(value="F7")
        self.playback_hotkey: Key | KeyCode = Key.f6
        self.playback_hotkey_display = tk.StringVar(value="F6")

        self.recording_manager = RecordingManager()
        self.current_recording_name = tk.StringVar(value="")
        self.recording_status = tk.StringVar(value="Pronto para gravar")
        self.recordings_list = []
        self.playback_loop = tk.BooleanVar(value=False)
        self.playback_speed = tk.DoubleVar(value=1.0)

        # Settings
        self.language = tk.StringVar(value="pt")
        self.theme = tk.StringVar(value="dark")

        self._capture_target = None
        self._captured_mouse_button = None

        self.basic_runner = ActionRunner()
        self.basic_mode = tk.StringVar(value="teclado")
        self.basic_action = tk.StringVar(value="loop")
        self.basic_interval_ms = tk.StringVar(value="100")
        self.basic_press_ms = tk.StringVar(value="50")
        self.basic_key_display = tk.StringVar(value="A")
        self.basic_key: Key | KeyCode | None = KeyCode.from_char("a")
        self.basic_mouse = tk.StringVar(value="esquerdo")
        self.basic_status = tk.StringVar(value="")

        self.slots: list[SlotCard] = []
        self.combos: list[dict] = []

        self._build_styles()
        self._build_shell()
        self._bind_autosave_vars()
        self._start_listener()
        self.root.bind("<F11>", lambda _e: self.toggle_fullscreen())
        self.root.bind("<Escape>", self._on_escape)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        saved = self.load_config()
        # Apply theme after loading config
        self.apply_theme()
        # Always open in basic mode
        self.show_basic(from_load=True)
        self._loading = False
        self._refresh_hotkey_labels()

    def t(self, key: str) -> str:
        """Get translation for a key based on current language"""
        lang = self.language.get()
        return TRANSLATIONS.get(lang, {}).get(key, key)

    # ─── Basic Menu ─────────────────────────────────────────────

    def show_basic_menu(self) -> None:
        menu = tk.Menu(self.root, tearoff=0)
        
        menu.add_command(label=self.t("advanced"), command=self.show_advanced)
        menu.add_command(label=self.t("recording"), command=self.show_recording_ui)
        menu.add_separator()
        menu.add_command(label=self.t("settings"), command=self.show_settings_window)
        
        # Show menu at cursor position
        x = self.root.winfo_pointerx()
        y = self.root.winfo_pointery()
        menu.post(x, y)

    # ─── Settings Window ─────────────────────────────────────────

    def show_settings_window(self) -> None:
        settings_win = tk.Toplevel(self.root)
        settings_win.title(self.t("settings"))
        settings_win.geometry("400x300")
        settings_win.configure(bg="#1a1d23")
        settings_win.transient(self.root)
        settings_win.grab_set()
        
        pad = {"padx": 16, "pady": 6}
        
        # Language selection
        lang_card = ttk.Frame(settings_win, style="Card.TFrame", padding=12)
        lang_card.pack(fill="x", **pad)
        ttk.Label(lang_card, text=self.t("language"), style="Card.TLabel").pack(anchor="w")
        
        lang_row = ttk.Frame(lang_card, style="Card.TFrame")
        lang_row.pack(anchor="w", pady=(8, 0))
        ttk.Radiobutton(
            lang_row, text=self.t("portuguese"), variable=self.language, value="pt"
        ).pack(side="left", padx=(0, 16))
        ttk.Radiobutton(
            lang_row, text=self.t("english"), variable=self.language, value="en"
        ).pack(side="left")
        
        # Theme selection
        theme_card = ttk.Frame(settings_win, style="Card.TFrame", padding=12)
        theme_card.pack(fill="x", **pad)
        ttk.Label(theme_card, text=self.t("theme"), style="Card.TLabel").pack(anchor="w")
        
        theme_row = ttk.Frame(theme_card, style="Card.TFrame")
        theme_row.pack(anchor="w", pady=(8, 0))
        
        themes = [
            ("Dark", "dark"),
            ("Light", "light"),
            ("Night", "night"),
            ("Red", "red"),
            ("Aurora", "aurora"),
            ("Hell", "hell")
        ]
        
        for label, value in themes:
            ttk.Radiobutton(
                theme_row, text=label, variable=self.theme, value=value
            ).pack(side="left", padx=(0, 8))
        
        # Apply button
        apply_btn = ttk.Button(
            settings_win, text=self.t("apply"), command=lambda: self.apply_settings()
        )
        apply_btn.pack(pady=16)
        
        def on_close():
            settings_win.destroy()
        
        settings_win.protocol("WM_DELETE_WINDOW", on_close)

    def apply_settings(self) -> None:
        self.apply_theme()
        self.schedule_save()
        # Clear and rebuild UI to apply language changes
        self.basic_frame.pack_forget()
        self.advanced_frame.pack_forget()
        self.recording_frame.pack_forget()
        
        # Clear existing widgets from basic and recording frames only
        for widget in self.basic_frame.winfo_children():
            widget.destroy()
        for widget in self.recording_frame.winfo_children():
            widget.destroy()
        
        # Rebuild UI
        self._build_basic_ui()
        self._build_recording_ui()
        
        # For advanced mode, just update text labels without destroying widgets
        # This preserves slots and their order
        self._update_advanced_ui_texts()
        
        # Show current mode
        if self.view_mode == "basico":
            self.basic_frame.pack(fill="both", expand=True)
        elif self.view_mode == "avancado":
            self.advanced_frame.pack(fill="both", expand=True)
        elif self.view_mode == "recording":
            self.recording_frame.pack(fill="both", expand=True)

    def _update_advanced_ui_texts(self) -> None:
        """Update text labels in advanced mode without destroying widgets"""
        # Update title label
        for widget in self.advanced_frame.winfo_children():
            if isinstance(widget, ttk.Frame):
                for child in widget.winfo_children():
                    if isinstance(child, ttk.Label) and child.cget("style") == "Title.TLabel":
                        child.configure(text=self.t("advanced"))
                    elif isinstance(child, ttk.Label) and child.cget("style") == "Sub.TLabel":
                        child.configure(text=self.t("drag_hint"))
                    elif isinstance(child, ttk.Label) and child.cget("style") == "Card.TLabel":
                        text = child.cget("text")
                        # Update known labels
                        if text in ["Janela", "Window"]:
                            child.configure(text=self.t("window"))
                        elif text in ["Largura:", "Width:"]:
                            child.configure(text=f"{self.t('width')}:")
                        elif text in ["Altura:", "Height:"]:
                            child.configure(text=f"{self.t('height')}:")
                        elif text in ["Atalho global (inicia/para TODAS as ações)", "Global hotkey (start/stop ALL)"]:
                            child.configure(text=self.t("global_hotkey"))
                    elif isinstance(child, ttk.Button):
                        text = child.cget("text")
                        if text in ["Capturar atalho", "Capture hotkey"]:
                            child.configure(text=self.t("capture_hotkey"))
                        elif text in ["Iniciar todas", "Start all"]:
                            child.configure(text=self.t("start_all"))
                        elif text in ["Parar todas", "Stop all"]:
                            child.configure(text=self.t("stop_all"))
                        elif text in ["Aplicar tamanho", "Apply size"]:
                            child.configure(text=self.t("apply_size"))
                        elif text in ["Maximizar", "Maximize"]:
                            child.configure(text=self.t("maximize"))
                        elif text in ["Restaurar", "Restore"]:
                            child.configure(text=self.t("restore"))
                        elif text in ["Tela cheia (F11)", "Fullscreen (F11)"]:
                            child.configure(text=self.t("fullscreen"))
                        elif text in ["+ Adicionar painel (tecla/mouse)", "+ Add panel (key/mouse)"]:
                            child.configure(text=self.t("add_panel"))

    def next_uid(self) -> int:
        self._uid_counter += 1
        return self._uid_counter

    def renumber_slots(self) -> None:
        for i, slot in enumerate(self.slots, start=1):
            slot.set_display_number(i)

    def relayout_docked_slots(self) -> None:
        """Garante ordem visual crescente (Painel 1, 2, 3…)."""
        for slot in self.slots:
            if not slot.detached and slot.frame is not None:
                try:
                    slot.frame.pack_forget()
                except Exception:
                    pass
        for slot in self.slots:
            if not slot.detached and slot.frame is not None:
                slot.frame.pack(fill="x", pady=6)

    # ─── Persistência ─────────────────────────────────────────

    def _bind_autosave_vars(self) -> None:
        for var in (
            self.basic_mode,
            self.basic_action,
            self.basic_interval_ms,
            self.basic_press_ms,
            self.basic_mouse,
            self.window_w,
            self.window_h,
        ):
            var.trace_add("write", lambda *_: self.schedule_save())

    def schedule_save(self) -> None:
        if self._loading:
            return
        if self._save_after_id is not None:
            try:
                self.root.after_cancel(self._save_after_id)
            except Exception:
                pass
        self._save_after_id = self.root.after(400, self.save_config)

    def save_config(self) -> None:
        if self._loading:
            return
        data = {
            "view_mode": self.view_mode,
            "hotkey": serialize_key(self.hotkey),
            "record_hotkey": serialize_key(self.record_hotkey),
            "playback_hotkey": serialize_key(self.playback_hotkey),
            "window": {
                "shared_geom": self._shared_geom,
                "w": self.window_w.get(),
                "h": self.window_h.get(),
                "main_geometry": self.root.geometry(),
            },
            "settings": {
                "language": self.language.get(),
                "theme": self.theme.get()
            },
            "basic": {
                "mode": self.basic_mode.get(),
                "action": self.basic_action.get(),
                "interval_ms": self.basic_interval_ms.get(),
                "press_ms": self.basic_press_ms.get(),
                "key": serialize_key(self.basic_key),
                "mouse": self.basic_mouse.get(),
            },
            "slots": [s.to_dict() for s in self.slots],
            "uid_counter": self._uid_counter,
            "combos": self.combos,
        }
        try:
            CONFIG_PATH.write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception:
            pass

    def load_config(self) -> dict:
        if not CONFIG_PATH.exists():
            return {}
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}

        hot = deserialize_key(data.get("hotkey"))
        if hot is not None:
            self.hotkey = hot
            self.hotkey_display.set(key_to_label(hot))

        rec_hot = deserialize_key(data.get("record_hotkey"))
        if rec_hot is not None:
            self.record_hotkey = rec_hot
            self.record_hotkey_display.set(key_to_label(rec_hot))
        else:
            self.record_hotkey = Key.f7
            self.record_hotkey_display.set("F7")

        play_hot = deserialize_key(data.get("playback_hotkey"))
        if play_hot is not None:
            self.playback_hotkey = play_hot
            self.playback_hotkey_display.set(key_to_label(play_hot))
        else:
            self.playback_hotkey = Key.f6
            self.playback_hotkey_display.set("F6")

        win = data.get("window") or {}
        if win.get("shared_geom"):
            self._shared_geom = win["shared_geom"]
        if win.get("w"):
            self.window_w.set(str(win["w"]))
        if win.get("h"):
            self.window_h.set(str(win["h"]))

        basic = data.get("basic") or {}
        if basic.get("mode"):
            self.basic_mode.set(basic["mode"])
        if basic.get("action"):
            self.basic_action.set(basic["action"])
        if basic.get("interval_ms") is not None:
            self.basic_interval_ms.set(str(basic["interval_ms"]))
        if basic.get("press_ms") is not None:
            self.basic_press_ms.set(str(basic["press_ms"]))
        if basic.get("mouse"):
            self.basic_mouse.set(basic["mouse"])
        bkey = deserialize_key(basic.get("key"))
        if bkey is not None:
            self.basic_key = bkey
            self.basic_key_display.set(key_to_label(bkey))

        self._uid_counter = int(data.get("uid_counter") or 0)
        self.combos = data.get("combos") or []
        
        # Load settings
        settings = data.get("settings") or {}
        if settings.get("language"):
            self.language.set(settings["language"])
        if settings.get("theme"):
            self.theme.set(settings["theme"])

        # Slots serão criados ao abrir avançado / aqui se já avançado
        self._pending_slots = data.get("slots") or None
        return data

    def _apply_pending_slots(self) -> None:
        pending = getattr(self, "_pending_slots", None)
        self._pending_slots = None
        if pending is None:
            if not self.slots:
                self.add_slot(default_key="w", action="segurar")
                self.add_slot(default_key="a", action="loop")
            return
        if not pending:
            return
        for item in pending:
            self.add_slot_from_dict(item)
        self.renumber_slots()

    # ─── UI shell ─────────────────────────────────────────────

    def _build_styles(self) -> None:
        self.apply_theme()

    def _build_shell(self) -> None:
        outer = ttk.Frame(self.root, style="TFrame")
        outer.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(outer, bg="#1a1d23", highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.content = ttk.Frame(self.canvas, style="TFrame")
        self._canvas_window = self.canvas.create_window(
            (0, 0), window=self.content, anchor="nw"
        )
        self.content.bind(
            "<Configure>",
            lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfigure(self._canvas_window, width=e.width),
        )
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

        self.basic_frame = ttk.Frame(self.content, style="TFrame")
        self.advanced_frame = ttk.Frame(self.content, style="TFrame")
        self.recording_frame = ttk.Frame(self.content, style="TFrame")
        self._build_basic_ui()
        self._build_advanced_ui()
        self._build_recording_ui()
        self.apply_theme()  # Apply theme again after frames are created

    def _on_mousewheel(self, event) -> None:
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def apply_theme(self) -> None:
        theme_name = self.theme.get()
        theme = THEMES.get(theme_name, THEMES["dark"])
        
        self.root.configure(bg=theme["bg"])
        
        # ttk frames use styles, not direct configure
        # Only configure the root window directly
        
        # Update ttk styles
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure("TFrame", background=theme["bg"])
        style.configure("Card.TFrame", background=theme["card_bg"])
        style.configure("Slot.TFrame", background=theme["input_bg"])
        style.configure("Title.TLabel", background=theme["bg"], foreground=theme["fg"], font=("Segoe UI Semibold", 16))
        style.configure("Sub.TLabel", background=theme["bg"], foreground=theme["fg"])
        style.configure("Card.TLabel", background=theme["card_bg"], foreground=theme["card_fg"])
        style.configure("Status.TLabel", background=theme["bg"], foreground=theme["accent"])
        style.configure("TButton", background=theme["input_bg"], foreground=theme["input_fg"])
        style.configure("Accent.TButton", background=theme["accent"], foreground="#ffffff")
        style.configure("TEntry", fieldbackground=theme["input_bg"], foreground=theme["input_fg"])
        style.configure("TCheckbutton", background=theme["bg"], foreground=theme["fg"])
        style.configure("TRadiobutton", background=theme["bg"], foreground=theme["fg"])
        
        # Update listbox colors
        if hasattr(self, '_recording_listbox'):
            self._recording_listbox.configure(bg=theme["input_bg"], fg=theme["input_fg"])
        
        # Update canvas background
        if hasattr(self, 'canvas'):
            self.canvas.configure(bg=theme["bg"])

    def _build_basic_ui(self) -> None:
        p = self.basic_frame
        pad = {"padx": 16, "pady": 6}

        head = ttk.Frame(p, style="TFrame")
        head.pack(fill="x", padx=16, pady=(16, 2))
        ttk.Label(head, text=self.t("basic"), style="Title.TLabel").pack(side="left")
        ttk.Button(head, text="⋮", command=self.show_basic_menu, width=3).pack(side="left", padx=(16, 0))

        # Hotkey card (first)
        hot = ttk.Frame(p, style="Card.TFrame", padding=12)
        hot.pack(fill="x", **pad)
        ttk.Label(hot, text=self.t("global_hotkey"), style="Card.TLabel").pack(anchor="w")
        row = ttk.Frame(hot, style="Card.TFrame")
        row.pack(fill="x", pady=(8, 0))
        ttk.Entry(
            row,
            textvariable=self.hotkey_display,
            width=14,
            state="readonly",
            justify="center",
            font=("Segoe UI Semibold", 12),
        ).pack(side="left", padx=(0, 8))
        self.basic_hotkey_btn = ttk.Button(
            row, text=self.t("capture_hotkey"), command=self._capture_hotkey
        )
        self.basic_hotkey_btn.pack(side="left")

        # Input mode card (teclado/mouse)
        mode_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        mode_card.pack(fill="x", **pad)
        ttk.Label(mode_card, text=self.t("input_type"), style="Card.TLabel").pack(anchor="w")
        mrow = ttk.Frame(mode_card, style="Card.TFrame")
        mrow.pack(anchor="w", pady=(8, 0))
        ttk.Radiobutton(
            mrow, text=self.t("keyboard"), variable=self.basic_mode, value="teclado", command=self._basic_show_input
        ).pack(side="left", padx=(0, 16))
        ttk.Radiobutton(
            mrow, text=self.t("mouse"), variable=self.basic_mode, value="mouse", command=self._basic_show_input
        ).pack(side="left")

        # Keyboard card
        self.basic_kb_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        self.basic_kb_card.pack(fill="x", **pad)
        ttk.Label(self.basic_kb_card, text=self.t("keyboard"), style="Card.TLabel").pack(anchor="w")
        krow = ttk.Frame(self.basic_kb_card, style="Card.TFrame")
        krow.pack(anchor="w", pady=(8, 0))
        ttk.Entry(
            krow,
            textvariable=self.basic_key_display,
            width=10,
            state="readonly",
            justify="center",
            font=("Segoe UI Semibold", 11),
        ).pack(side="left", padx=(0, 8))
        ttk.Button(krow, text=self.t("capture_key"), command=self._capture_basic_key).pack(side="left")

        # Mouse card
        self.basic_mouse_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        self.basic_mouse_card.pack(fill="x", **pad)
        ttk.Label(self.basic_mouse_card, text=self.t("button"), style="Card.TLabel").pack(anchor="w")
        brow = ttk.Frame(self.basic_mouse_card, style="Card.TFrame")
        brow.pack(anchor="w", pady=(8, 0))
        for label, value in (
            (self.t("left"), "esquerdo"),
            (self.t("middle"), "meio"),
            (self.t("right"), "direito"),
        ):
            ttk.Radiobutton(
                brow, text=label, variable=self.basic_mouse, value=value
            ).pack(side="left", padx=(0, 12))

        # Action mode card (loop/segurar)
        action_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        action_card.pack(fill="x", **pad)
        ttk.Label(action_card, text=self.t("action_mode"), style="Card.TLabel").pack(anchor="w")
        arow = ttk.Frame(action_card, style="Card.TFrame")
        arow.pack(anchor="w", pady=(8, 0))
        ttk.Radiobutton(
            arow,
            text=f"{self.t('loop')} (repetir)",
            variable=self.basic_action,
            value="loop",
            command=self._basic_refresh_timing,
        ).pack(side="left", padx=(0, 16))
        ttk.Radiobutton(
            arow,
            text=self.t("hold"),
            variable=self.basic_action,
            value="segurar",
            command=self._basic_refresh_timing,
        ).pack(side="left")

        self.basic_timing = ttk.Frame(action_card, style="Card.TFrame")
        self.basic_timing.pack(fill="x", pady=(10, 0))
        irow = ttk.Frame(self.basic_timing, style="Card.TFrame")
        irow.pack(fill="x")
        ttk.Label(irow, text=self.t("interval_ms"), style="Card.TLabel").pack(
            side="left"
        )
        self.basic_interval_entry = ttk.Entry(
            irow, textvariable=self.basic_interval_ms, width=10
        )
        self.basic_interval_entry.pack(side="left", padx=(8, 0))
        prow = ttk.Frame(self.basic_timing, style="Card.TFrame")
        prow.pack(fill="x", pady=(8, 0))
        ttk.Label(
            prow, text=self.t("press_ms"), style="Card.TLabel"
        ).pack(side="left")
        self.basic_press_entry = ttk.Entry(
            prow, textvariable=self.basic_press_ms, width=10
        )
        self.basic_press_entry.pack(side="left", padx=(8, 0))

        ctrl = ttk.Frame(p, style="TFrame")
        ctrl.pack(fill="x", padx=16, pady=12)
        self.basic_toggle_btn = ttk.Button(
            ctrl, text=self.t("start"), style="Accent.TButton", command=self.toggle_basic
        )
        self.basic_toggle_btn.pack(fill="x")
        ttk.Label(p, textvariable=self.basic_status, style="Status.TLabel").pack(
            anchor="w", padx=16, pady=(0, 16)
        )

        # Show correct input card based on mode
        if self.basic_mode.get() == "teclado":
            self.basic_mouse_card.pack_forget()
        else:
            self.basic_kb_card.pack_forget()
        
        self._basic_refresh_timing()

    def _basic_show_input(self) -> None:
        # Don't use pack_forget/pack which can reorder elements
        # Instead, just control visibility with grid or keep both visible
        if self.basic_mode.get() == "teclado":
            self.basic_kb_card.pack(fill="x", **{"padx": 16, "pady": 6})
            self.basic_mouse_card.pack_forget()
        else:
            self.basic_mouse_card.pack(fill="x", **{"padx": 16, "pady": 6})
            self.basic_kb_card.pack_forget()
        self.schedule_save()

    def _basic_refresh_timing(self) -> None:
        state = "normal" if self.basic_action.get() == "loop" else "disabled"
        self.basic_interval_entry.configure(state=state)
        self.basic_press_entry.configure(state=state)
        self.schedule_save()

    def _build_advanced_ui(self) -> None:
        p = self.advanced_frame
        pad = {"padx": 16, "pady": 6}

        head = ttk.Frame(p, style="TFrame")
        head.pack(fill="x", padx=16, pady=(16, 2))
        ttk.Label(head, text=self.t("advanced"), style="Title.TLabel").pack(side="left")
        ttk.Button(head, text="⋮", command=self.show_advanced_menu, width=3).pack(side="left", padx=(16, 0))
        ttk.Label(
            p,
            text=self.t("drag_hint"),
            style="Sub.TLabel",
        ).pack(anchor="w", padx=16, pady=(0, 10))

        win = ttk.Frame(p, style="Card.TFrame", padding=12)
        win.pack(fill="x", **pad)
        ttk.Label(win, text=self.t("window"), style="Card.TLabel").pack(anchor="w")
        srow = ttk.Frame(win, style="Card.TFrame")
        srow.pack(fill="x", pady=(8, 0))
        ttk.Label(srow, text=f"{self.t('width')}:", style="Card.TLabel").pack(side="left")
        ttk.Entry(srow, textvariable=self.window_w, width=7).pack(
            side="left", padx=(6, 12)
        )
        ttk.Label(srow, text=f"{self.t('height')}:", style="Card.TLabel").pack(side="left")
        ttk.Entry(srow, textvariable=self.window_h, width=7).pack(
            side="left", padx=(6, 12)
        )
        ttk.Button(srow, text=self.t("apply_size"), command=self.apply_window_size).pack(
            side="left"
        )
        brow = ttk.Frame(win, style="Card.TFrame")
        brow.pack(fill="x", pady=(8, 0))
        ttk.Button(brow, text=self.t("maximize"), command=self.maximize_window).pack(
            side="left", padx=(0, 8)
        )
        ttk.Button(brow, text=self.t("restore"), command=self.restore_window).pack(
            side="left", padx=(0, 8)
        )
        ttk.Button(
            brow, text=self.t("fullscreen"), command=self.toggle_fullscreen
        ).pack(side="left")

        hot = ttk.Frame(p, style="Card.TFrame", padding=12)
        hot.pack(fill="x", **pad)
        ttk.Label(
            hot, text=self.t("global_hotkey"), style="Card.TLabel"
        ).pack(anchor="w")
        hrow = ttk.Frame(hot, style="Card.TFrame")
        hrow.pack(fill="x", pady=(8, 0))
        ttk.Entry(
            hrow,
            textvariable=self.hotkey_display,
            width=14,
            state="readonly",
            justify="center",
            font=("Segoe UI Semibold", 12),
        ).pack(side="left", padx=(0, 8))
        self.adv_hotkey_btn = ttk.Button(
            hrow, text=self.t("capture_hotkey"), command=self._capture_hotkey
        )
        self.adv_hotkey_btn.pack(side="left", padx=(0, 8))
        ttk.Button(hrow, text=self.t("start_all"), command=self.start_all_slots).pack(
            side="left", padx=(0, 8)
        )
        ttk.Button(hrow, text=self.t("stop_all"), command=self.stop_all_slots).pack(
            side="left"
        )

        tools = ttk.Frame(p, style="TFrame")
        tools.pack(fill="x", padx=16, pady=(4, 6))
        ttk.Button(
            tools, text=self.t("add_panel"), command=self.add_slot
        ).pack(side="left")

        self.slots_host = ttk.Frame(p, style="TFrame")
        self.slots_host.pack(fill="both", expand=True, padx=16, pady=(0, 16))

    def _build_recording_ui(self) -> None:
        p = self.recording_frame
        pad = {"padx": 16, "pady": 6}

        head = ttk.Frame(p, style="TFrame")
        head.pack(fill="x", padx=16, pady=(16, 2))
        ttk.Label(head, text=self.t("recording"), style="Title.TLabel").pack(side="left")
        ttk.Button(head, text="⋮", command=self.show_recording_menu, width=3).pack(side="left", padx=(16, 0))
        
        # Hotkeys configuration
        hotkeys_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        hotkeys_card.pack(fill="x", **pad)
        ttk.Label(hotkeys_card, text=self.t("recording_hotkeys"), style="Card.TLabel").pack(anchor="w")
        
        rec_row = ttk.Frame(hotkeys_card, style="Card.TFrame")
        rec_row.pack(fill="x", pady=(8, 4))
        ttk.Label(rec_row, text=self.t("record_hotkey"), style="Card.TLabel").pack(side="left")
        ttk.Entry(
            rec_row,
            textvariable=self.record_hotkey_display,
            width=10,
            state="readonly",
            justify="center",
            font=("Segoe UI Semibold", 11),
        ).pack(side="left", padx=(8, 8))
        ttk.Button(
            rec_row, text=self.t("capture"), command=self._capture_record_hotkey
        ).pack(side="left")

        play_row = ttk.Frame(hotkeys_card, style="Card.TFrame")
        play_row.pack(fill="x", pady=(4, 0))
        ttk.Label(play_row, text=self.t("playback_hotkey"), style="Card.TLabel").pack(side="left")
        ttk.Entry(
            play_row,
            textvariable=self.playback_hotkey_display,
            width=10,
            state="readonly",
            justify="center",
            font=("Segoe UI Semibold", 11),
        ).pack(side="left", padx=(8, 8))
        ttk.Button(
            play_row, text=self.t("capture"), command=self._capture_playback_hotkey
        ).pack(side="left")

        # Recording controls
        record_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        record_card.pack(fill="x", **pad)
        ttk.Label(record_card, text=self.t("recording"), style="Card.TLabel").pack(anchor="w")
        
        ctrl_row = ttk.Frame(record_card, style="Card.TFrame")
        ctrl_row.pack(fill="x", pady=(8, 0))
        ttk.Button(
            ctrl_row, text=f"● {self.t('record')}", command=self.toggle_recording, style="Accent.TButton"
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            ctrl_row, text=f"▶ {self.t('play')}", command=self.play_selected_recording
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            ctrl_row, text=f"■ {self.t('stop')}", command=self.stop_playback
        ).pack(side="left")

        ttk.Label(record_card, textvariable=self.recording_status, style="Status.TLabel").pack(
            anchor="w", pady=(8, 0)
        )

        # Playback options
        options_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        options_card.pack(fill="x", **pad)
        ttk.Label(options_card, text=self.t("playback"), style="Card.TLabel").pack(anchor="w")
        
        loop_row = ttk.Frame(options_card, style="Card.TFrame")
        loop_row.pack(fill="x", pady=(8, 0))
        ttk.Checkbutton(
            loop_row, text=f"{self.t('loop')} (repetir)", variable=self.playback_loop
        ).pack(side="left")
        
        speed_row = ttk.Frame(options_card, style="Card.TFrame")
        speed_row.pack(fill="x", pady=(8, 0))
        ttk.Label(speed_row, text=f"{self.t('playback_speed')} (0.5x - 15x):", style="Card.TLabel").pack(side="left")
        ttk.Entry(
            speed_row, textvariable=self.playback_speed, width=10
        ).pack(side="left", padx=(8, 8))
        ttk.Label(speed_row, text="x", style="Card.TLabel").pack(side="left")

        # Save recording
        save_row = ttk.Frame(record_card, style="Card.TFrame")
        save_row.pack(fill="x", pady=(8, 0))
        ttk.Label(save_row, text="Nome:", style="Card.TLabel").pack(side="left")
        ttk.Entry(
            save_row, textvariable=self.current_recording_name, width=20
        ).pack(side="left", padx=(8, 8))
        ttk.Button(
            save_row, text=self.t("save_recording"), command=self.save_recording
        ).pack(side="left")

        # Recordings list
        list_card = ttk.Frame(p, style="Card.TFrame", padding=12)
        list_card.pack(fill="both", expand=True, **pad)
        ttk.Label(list_card, text=self.t("recordings_list"), style="Card.TLabel").pack(anchor="w")
        
        list_ctrl = ttk.Frame(list_card, style="Card.TFrame")
        list_ctrl.pack(fill="x", pady=(8, 0))
        ttk.Button(
            list_ctrl, text="Atualizar", command=lambda: self.refresh_recordings_list(self._recording_listbox)
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            list_ctrl, text=self.t("load"), command=lambda: self.load_selected_recording_from_list(self._recording_listbox)
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            list_ctrl, text=self.t("delete"), command=lambda: self.delete_selected_recording_from_list(self._recording_listbox)
        ).pack(side="left")

        self._recording_listbox = tk.Listbox(
            list_card, bg="#1e232b", fg="#e8eaed", selectmode="single", height=8
        )
        self._recording_listbox.pack(fill="both", expand=True, pady=(8, 0))
        self._recording_listbox.bind("<<ListboxSelect>>", lambda e: self._on_recording_select_from_list(e, self._recording_listbox))
        
        # Initial refresh
        self.refresh_recordings_list(self._recording_listbox)

    # ─── Advanced Menu ─────────────────────────────────────────────

    def show_advanced_menu(self) -> None:
        menu = tk.Menu(self.root, tearoff=0)
        
        menu.add_command(label=self.t("basic"), command=self.show_basic)
        menu.add_separator()
        
        # Combos section
        if self.combos:
            for combo in self.combos:
                combo_menu = tk.Menu(menu, tearoff=0)
                combo_menu.add_command(label=f"{self.t('load')} '{combo['name']}'", 
                                       command=lambda c=combo['name']: self.load_combo(c))
                combo_menu.add_command(label=f"{self.t('delete')} '{combo['name']}'", 
                                       command=lambda c=combo['name']: self.delete_combo(c))
                menu.add_cascade(label=combo['name'], menu=combo_menu)
        else:
            menu.add_command(label="Nenhum combo salvo", state="disabled")
        
        menu.add_separator()
        menu.add_command(label=f"{self.t('save')} {self.t('combo')}", command=self.save_combo)
        menu.add_separator()
        menu.add_command(label=self.t("recording"), command=self.show_recording_ui)
        menu.add_separator()
        menu.add_command(label=self.t("settings"), command=self.show_settings_window)
        
        # Show menu at cursor position
        x = self.root.winfo_pointerx()
        y = self.root.winfo_pointery()
        menu.post(x, y)

    # ─── Recording Methods ─────────────────────────────────────────

    def show_recording_menu(self) -> None:
        menu = tk.Menu(self.root, tearoff=0)
        
        menu.add_command(label=self.t("basic"), command=self.show_basic)
        menu.add_command(label=self.t("advanced"), command=self.show_advanced)
        menu.add_separator()
        menu.add_command(label=self.t("settings"), command=self.show_settings_window)
        
        # Show menu at cursor position
        x = self.root.winfo_pointerx()
        y = self.root.winfo_pointery()
        menu.post(x, y)

    # ─── Recording Methods (actual recording logic) ─────────────────────────────────────

    def show_recording_ui(self) -> None:
        # Stop all advanced mode slots before opening recording
        self.stop_all_slots()
        
        # Hide advanced mode properly
        if self.view_mode == "avancado":
            for slot in list(self.slots):
                if slot.detached:
                    slot.reattach(silent=True)
        
        self.view_mode = "recording"
        self.basic_frame.pack_forget()
        self.advanced_frame.pack_forget()
        self.recording_frame.pack(fill="both", expand=True)
        
        if not self._fullscreen:
            self.root.geometry("500x600")
        self.root.title("Auto Clicker / Tecla — Gravar/Reproduzir")
        
        # Set recording window reference to enable hotkeys
        self._recording_window = True

    def refresh_recordings_list(self, listbox=None) -> None:
        if listbox is None:
            listbox = getattr(self, "_recording_listbox", None)
        if listbox is None:
            return
        listbox.delete(0, tk.END)
        try:
            for file_path in RECORDINGS_DIR.glob("*.json"):
                listbox.insert(tk.END, file_path.stem)
        except Exception:
            pass

    def _on_recording_select_from_list(self, event, listbox) -> None:
        selection = listbox.curselection()
        if selection:
            name = listbox.get(selection[0])
            self.current_recording_name.set(name)

    def load_selected_recording_from_list(self, listbox) -> None:
        selection = listbox.curselection()
        if not selection:
            messagebox.showinfo("Aviso", "Selecione uma gravação.")
            return
        name = listbox.get(selection[0])
        file_path = RECORDINGS_DIR / f"{name}.json"
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                self.recording_manager.events = json.load(f)
            self.current_recording_name.set(name)
            self.recording_status.set(f"Gravação '{name}' carregada - {len(self.recording_manager.events)} eventos")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao carregar: {e}")

    def delete_selected_recording_from_list(self, listbox) -> None:
        selection = listbox.curselection()
        if not selection:
            messagebox.showinfo("Aviso", "Selecione uma gravação.")
            return
        name = listbox.get(selection[0])
        if not messagebox.askyesno("Confirmar", f"Deletar '{name}'?"):
            return
        file_path = RECORDINGS_DIR / f"{name}.json"
        try:
            file_path.unlink()
            self.refresh_recordings_list(listbox)
            self.recording_status.set(f"Gravação '{name}' deletada")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao deletar: {e}")

    def _capture_record_hotkey(self) -> None:
        if self.recording_manager.recording or self.recording_manager.playing:
            messagebox.showinfo("Aviso", "Pare a gravação/reprodução antes de capturar.")
            return
        self._capture_target = "record_hotkey"
        self.record_hotkey_display.set("Pressione...")
        self.recording_status.set("Aguardando tecla ou botão lateral do mouse...")
        self._set_capture_buttons(False)

    def _capture_playback_hotkey(self) -> None:
        if self.recording_manager.recording or self.recording_manager.playing:
            messagebox.showinfo("Aviso", "Pare a gravação/reprodução antes de capturar.")
            return
        self._capture_target = "playback_hotkey"
        self.playback_hotkey_display.set("Pressione...")
        self.recording_status.set("Aguardando tecla ou botão lateral do mouse...")
        self._set_capture_buttons(False)

    def toggle_recording(self) -> None:
        if self.recording_manager.recording:
            events = self.recording_manager.stop_recording()
            if events:
                self.recording_status.set(f"Gravação parada - {len(events)} eventos")
                if not self.current_recording_name.get():
                    self.current_recording_name.set("gravacao_temp")
            else:
                self.recording_status.set("Erro ao parar gravação")
        else:
            if self.recording_manager.playing:
                messagebox.showinfo("Aviso", "Pare a reprodução antes de gravar.")
                return
            if self.recording_manager.start_recording():
                self.recording_status.set("Gravando... (pressione novamente para parar)")
            else:
                self.recording_status.set("Erro ao iniciar gravação")

    def save_recording(self) -> None:
        if not self.recording_manager.events:
            messagebox.showinfo("Aviso", "Não há gravação para salvar.")
            return
        name = self.current_recording_name.get().strip()
        if not name:
            messagebox.showerror("Erro", "Digite um nome para a gravação.")
            return
        
        file_path = RECORDINGS_DIR / f"{name}.json"
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.recording_manager.events, f, ensure_ascii=False, indent=2)
            self.recording_status.set(f"Gravação salva como '{name}'")
            # Refresh the listbox if it exists
            if hasattr(self, '_recording_listbox') and self._recording_listbox:
                self.refresh_recordings_list(self._recording_listbox)
            self.recording_manager.events = []
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar: {e}")

    def play_selected_recording(self) -> None:
        if not self.recording_manager.events:
            messagebox.showinfo("Aviso", "Carregue ou grave algo primeiro.")
            return
        if self.recording_manager.recording:
            messagebox.showinfo("Aviso", "Pare a gravação antes de reproduzir.")
            return
        
        def on_complete():
            self.root.after(0, lambda: self.recording_status.set("Reprodução concluída"))

        def on_error(error):
            self.root.after(0, lambda: messagebox.showerror("Erro", f"Erro na reprodução: {error}"))

        loop = self.playback_loop.get()
        speed = self.playback_speed.get()
        
        if self.recording_manager.play_recording(self.recording_manager.events, on_complete, on_error, loop, speed):
            self.recording_status.set(f"Reproduzindo... (Loop: {loop}, Velocidade: {speed}x)")

    def stop_playback(self) -> None:
        self.recording_manager.stop_playback()
        self.recording_status.set("Reprodução parada")

    def toggle_playback_hotkey(self) -> None:
        if self.recording_manager.playing:
            self.stop_playback()
        else:
            self.play_selected_recording()

    # ─── Combo Methods ───────────────────────────────────────────

    def save_combo(self) -> None:
        from tkinter import simpledialog
        name = simpledialog.askstring("Salvar Combo", "Nome do combo:")
        if not name:
            return
        combo_data = {
            "name": name,
            "slots": [s.to_dict() for s in self.slots]
        }
        self.combos.append(combo_data)
        self.schedule_save()
        messagebox.showinfo("Sucesso", f"Combo '{name}' salvo!")

    def load_combo(self, combo_name: str) -> None:
        combo = next((c for c in self.combos if c["name"] == combo_name), None)
        if not combo:
            messagebox.showerror("Erro", "Combo não encontrado.")
            return
        
        if not messagebox.askyesno("Confirmar", "Isso substituirá todos os painéis atuais. Continuar?"):
            return
        
        # Stop all current slots
        self.stop_all_slots()
        
        # Remove all current slots
        for slot in list(self.slots):
            slot.destroy_ui()
        self.slots = []
        
        # Load combo slots
        for slot_data in combo["slots"]:
            self.add_slot_from_dict(slot_data)
        
        self.renumber_slots()
        self.relayout_docked_slots()
        self.schedule_save()
        messagebox.showinfo("Sucesso", f"Combo '{combo_name}' carregado!")

    def delete_combo(self, combo_name: str) -> None:
        if not messagebox.askyesno("Confirmar", f"Deletar combo '{combo_name}'?"):
            return
        self.combos = [c for c in self.combos if c["name"] != combo_name]
        self.schedule_save()
        messagebox.showinfo("Sucesso", f"Combo '{combo_name}' deletado!")

    def add_slot(
        self,
        default_key: str = "a",
        action: str = "loop",
        *,
        from_dict: dict | None = None,
    ) -> "SlotCard":
        uid = self.next_uid()
        display = len(self.slots) + 1
        slot = SlotCard(
            app=self,
            uid=uid,
            display_number=display,
            default_key=default_key,
            default_action=action,
        )
        self.slots.append(slot)
        if from_dict:
            slot.apply_dict(from_dict)
        if slot.detached:
            slot.show_detached(restore_geom=from_dict.get("geometry") if from_dict else None)
        else:
            slot.show_docked()
        self.renumber_slots()
        self.schedule_save()
        return slot

    def add_slot_from_dict(self, data: dict) -> "SlotCard":
        return self.add_slot(from_dict=data)

    def remove_slot(self, slot: "SlotCard") -> None:
        slot.destroy_ui()
        slot.stop()
        self.slots = [s for s in self.slots if s is not slot]
        self.renumber_slots()
        self.schedule_save()

    def show_basic(self, from_load: bool = False) -> None:
        if self.view_mode == "avancado" and not from_load:
            self.stop_all_slots()
            for slot in list(self.slots):
                if slot.detached:
                    slot.reattach(silent=True)
        elif self.view_mode == "recording" and not from_load:
            # Stop recording/playback when leaving recording mode
            if self.recording_manager.recording:
                self.recording_manager.stop_recording()
            if self.recording_manager.playing:
                self.recording_manager.stop_playback()
            self._recording_window = None
        
        self.view_mode = "basico"
        self.advanced_frame.pack_forget()
        self.recording_frame.pack_forget()
        self.basic_frame.pack(fill="both", expand=True)
        if not self._fullscreen:
            self.root.geometry(self._shared_geom)
        self.root.title("Auto Clicker / Tecla — Básico")
        self._basic_show_input()
        self._basic_refresh_timing()
        self._refresh_hotkey_labels()
        if not from_load:
            self.schedule_save()

    def show_advanced(self, from_load: bool = False) -> None:
        if self.view_mode == "basico" and not from_load:
            self.stop_basic()
        elif self.view_mode == "recording" and not from_load:
            # Stop recording/playback when leaving recording mode
            if self.recording_manager.recording:
                self.recording_manager.stop_recording()
            if self.recording_manager.playing:
                self.recording_manager.stop_playback()
            self._recording_window = None
        
        self.view_mode = "avancado"
        self.basic_frame.pack_forget()
        self.recording_frame.pack_forget()
        self.advanced_frame.pack(fill="both", expand=True)
        if not self._fullscreen:
            self.root.geometry(self._shared_geom)
        self.root.title("Auto Clicker / Tecla — Avançado")
        if not self.slots:
            self._apply_pending_slots()
        self._refresh_hotkey_labels()
        if not from_load:
            self.schedule_save()

    def apply_window_size(self) -> None:
        try:
            w = int(self.window_w.get())
            h = int(self.window_h.get())
            if w < 420 or h < 400:
                raise ValueError
        except ValueError:
            messagebox.showerror(
                "Erro", "Informe largura ≥ 420 e altura ≥ 400 (números inteiros)."
            )
            return
        if self._fullscreen:
            self.toggle_fullscreen()
        self.root.state("normal")
        geom = f"{w}x{h}"
        self.root.geometry(geom)
        # Apply shared geometry
        self._shared_geom = geom
        self.schedule_save()

    def maximize_window(self) -> None:
        if self._fullscreen:
            self.toggle_fullscreen()
        self.root.state("zoomed")

    def restore_window(self) -> None:
        if self._fullscreen:
            self.toggle_fullscreen()
        self.root.state("normal")
        self.apply_window_size()

    def toggle_fullscreen(self) -> None:
        self._fullscreen = not self._fullscreen
        if self._fullscreen:
            self._geom_before_fullscreen = self.root.geometry()
            self.root.attributes("-fullscreen", True)
        else:
            self.root.attributes("-fullscreen", False)
            if self._geom_before_fullscreen:
                self.root.geometry(self._geom_before_fullscreen)

    def _on_escape(self, _event=None) -> None:
        if self._fullscreen:
            self.toggle_fullscreen()

    def _capture_hotkey(self) -> None:
        if self._any_running():
            messagebox.showinfo("Aviso", "Pare a automação antes de capturar o atalho.")
            return
        self._capture_target = "hotkey"
        self.hotkey_display.set("Pressione...")
        self.basic_status.set("Aguardando atalho (tecla ou botão lateral do mouse)...")
        self._set_capture_buttons(False)

    def _capture_basic_key(self) -> None:
        if self.basic_runner.running:
            messagebox.showinfo("Aviso", "Pare a automação antes de capturar.")
            return
        self._capture_target = "basic_key"
        self.basic_key_display.set("Pressione...")
        self.basic_status.set("Aguardando tecla...")
        self._set_capture_buttons(False)

    def request_slot_key_capture(self, slot: "SlotCard") -> None:
        if self._any_running():
            messagebox.showinfo("Aviso", "Pare as ações antes de capturar.")
            return
        self._capture_target = ("slot_key", slot.uid)
        slot.key_display.set("Pressione...")
        slot.status.set("Aguardando tecla...")
        self._set_capture_buttons(False)

    def _set_capture_buttons(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        for btn in (
            getattr(self, "basic_hotkey_btn", None),
            getattr(self, "basic_key_btn", None),
            getattr(self, "adv_hotkey_btn", None),
            getattr(self, "record_hotkey_btn", None),
            getattr(self, "playback_hotkey_btn", None),
        ):
            if btn is not None:
                btn.configure(state=state)
        for slot in self.slots:
            slot.set_capture_enabled(enabled)

    def _finish_capture(self, key) -> None:
        target = self._capture_target
        self._capture_target = None
        self._set_capture_buttons(True)

        if target == "hotkey":
            self.hotkey = key
            self.hotkey_display.set(key_to_label(key))
            self._refresh_hotkey_labels()
            self.basic_status.set("Pronto")
            self.schedule_save()
        elif target == "basic_key":
            self.basic_key = key
            self.basic_key_display.set(key_to_label(key))
            self._refresh_hotkey_labels()
            self.basic_status.set("Pronto")
            self.schedule_save()
        elif isinstance(target, tuple) and target[0] == "slot_key":
            uid = target[1]
            for slot in self.slots:
                if slot.uid == uid:
                    slot.set_key(key)
                    break
            self.schedule_save()
        elif target == "record_hotkey":
            self.record_hotkey = key
            self.record_hotkey_display.set(key_to_label(key))
            self.recording_status.set("Pronto para gravar")
            self.schedule_save()
        elif target == "playback_hotkey":
            self.playback_hotkey = key
            self.playback_hotkey_display.set(key_to_label(key))
            self.recording_status.set("Pronto para gravar")
            self.schedule_save()
        # Handle mouse button capture via keyboard listener (shouldn't happen but just in case)
        elif isinstance(key, Button):
            if target == "hotkey":
                self.hotkey = key
                self.hotkey_display.set(button_to_label(key))
                self._refresh_hotkey_labels()
                self.basic_status.set("Pronto")
                self.schedule_save()
            elif target == "record_hotkey":
                self.record_hotkey = key
                self.record_hotkey_display.set(button_to_label(key))
                self.recording_status.set("Pronto para gravar")
                self.schedule_save()
            elif target == "playback_hotkey":
                self.playback_hotkey = key
                self.playback_hotkey_display.set(button_to_label(key))
                self.recording_status.set("Pronto para gravar")
                self.schedule_save()

    def _finish_mouse_capture(self, button: Button) -> None:
        target = self._capture_target
        self._capture_target = None
        self._set_capture_buttons(True)

        if target == "hotkey":
            self.hotkey = button
            self.hotkey_display.set(button_to_label(button))
            self._refresh_hotkey_labels()
            self.basic_status.set("Pronto")
            self.schedule_save()
        elif target == "record_hotkey":
            self.record_hotkey = button
            self.record_hotkey_display.set(button_to_label(button))
            self.recording_status.set("Pronto para gravar")
            self.schedule_save()
        elif target == "playback_hotkey":
            self.playback_hotkey = button
            self.playback_hotkey_display.set(button_to_label(button))
            self.recording_status.set("Pronto para gravar")
            self.schedule_save()

    def _start_listener(self) -> None:
        def on_press(key):
            if self._capture_target is not None:
                self.root.after(0, lambda k=key: self._finish_capture(k))
                return
            # Only process global hotkey if not in recording mode
            if self.view_mode != "recording":
                if keys_equal(key, self.hotkey):
                    self.root.after(0, self._on_global_hotkey)
            # Only check recording hotkeys if recording window is open and visible
            if hasattr(self, '_recording_window') and self._recording_window and self.view_mode == "recording":
                if keys_equal(key, self.record_hotkey):
                    # Ignore record hotkey during playback
                    if not self.recording_manager.playing:
                        self.root.after(0, self.toggle_recording)
                if keys_equal(key, self.playback_hotkey):
                    self.root.after(0, self.toggle_playback_hotkey)

        def on_click(x, y, button, pressed):
            if self._capture_target is not None and pressed:
                # Only capture side buttons (x1, x2) for hotkeys
                if button in (Button.x1, Button.x2):
                    # Create a closure to capture the button value
                    captured_button = button
                    def finish_capture():
                        self._finish_mouse_capture(captured_button)
                    self.root.after(0, finish_capture)
                    return
            # Process mouse hotkey if set to a mouse button
            if self.view_mode != "recording" and pressed:
                if isinstance(self.hotkey, Button) and button == self.hotkey:
                    self.root.after(0, self._on_global_hotkey)
            # Only check recording hotkeys if recording window is open and visible
            if hasattr(self, '_recording_window') and self._recording_window and self.view_mode == "recording" and pressed:
                if isinstance(self.record_hotkey, Button) and button == self.record_hotkey:
                    # Ignore record hotkey during playback
                    if not self.recording_manager.playing:
                        self.root.after(0, self.toggle_recording)
                if isinstance(self.playback_hotkey, Button) and button == self.playback_hotkey:
                    self.root.after(0, self.toggle_playback_hotkey)

        self.listener = KeyboardListener(on_press=on_press)
        self.listener.daemon = True
        self.listener.start()
        
        self.mouse_hotkey_listener = MouseListener(on_click=on_click)
        self.mouse_hotkey_listener.daemon = True
        self.mouse_hotkey_listener.start()

    def _on_global_hotkey(self) -> None:
        if self.view_mode == "basico":
            self.toggle_basic()
        else:
            if any(s.runner.running for s in self.slots):
                self.stop_all_slots()
            else:
                self.start_all_slots()

    def _refresh_hotkey_labels(self) -> None:
        label = key_to_label(self.hotkey)
        if self.view_mode == "basico":
            if self.basic_runner.running:
                self.basic_toggle_btn.configure(text=f"Parar ({label})")
                self.basic_status.set(f"Em execução... — {label} para parar")
            else:
                self.basic_toggle_btn.configure(text=f"Iniciar ({label})")
                self.basic_status.set(
                    f"Parado — pressione {label} ou o botão para iniciar"
                )
        else:
            for slot in self.slots:
                slot.refresh_button_label()

    def _any_running(self) -> bool:
        return self.basic_runner.running or any(s.runner.running for s in self.slots)

    def toggle_basic(self) -> None:
        if self.basic_runner.running:
            self.stop_basic()
        else:
            self.start_basic()

    def start_basic(self) -> None:
        if self.basic_runner.running or self._capture_target is not None:
            return
        try:
            interval = press = 0.0
            if self.basic_action.get() == "loop":
                interval = parse_ms(self.basic_interval_ms.get(), "intervalo")
                press = parse_ms(self.basic_press_ms.get(), "tempo pressionado", 0)
        except ValueError as exc:
            messagebox.showerror("Erro", str(exc))
            return
        if self.basic_mode.get() == "teclado" and self.basic_key is None:
            messagebox.showerror("Erro", "Capture uma tecla antes de iniciar.")
            return
        if (
            self.basic_mode.get() == "teclado"
            and self.basic_action.get() == "segurar"
            and keys_equal(self.basic_key, self.hotkey)
        ):
            messagebox.showerror(
                "Erro",
                "A tecla de ação e o atalho iniciar/parar não podem ser a mesma.",
            )
            return

        self.basic_runner.start(
            input_mode=self.basic_mode.get(),
            action=self.basic_action.get(),
            key=self.basic_key,
            mouse_btn=self.basic_mouse.get(),
            interval=interval,
            press_duration=press,
            on_error=lambda e: self.root.after(
                0, lambda: messagebox.showerror("Erro", e)
            ),
            on_stopped=lambda: self.root.after(0, self._refresh_hotkey_labels),
        )
        self._refresh_hotkey_labels()

    def stop_basic(self) -> None:
        self.basic_runner.stop()
        self._refresh_hotkey_labels()

    def start_all_slots(self) -> None:
        errors = []
        for slot in self.slots:
            err = slot.start()
            if err:
                errors.append(f"Painel {slot.display_number}: {err}")
        if errors:
            messagebox.showerror("Erro", "\n".join(errors))

    def stop_all_slots(self) -> None:
        for slot in self.slots:
            slot.stop()

    def _on_close(self) -> None:
        self.stop_basic()
        self.stop_all_slots()
        for slot in list(self.slots):
            if slot.detached and slot.float_win is not None:
                try:
                    slot._float_geom = slot.float_win.geometry()
                except Exception:
                    pass
        self.save_config()
        try:
            self.canvas.unbind_all("<MouseWheel>")
        except Exception:
            pass
        try:
            self.listener.stop()
        except Exception:
            pass
        try:
            if hasattr(self, 'mouse_hotkey_listener'):
                self.mouse_hotkey_listener.stop()
        except Exception:
            pass
        for slot in list(self.slots):
            slot.destroy_ui()
        self.root.destroy()


class SlotCard:
    """Painel independente — pode ficar dockado ou em janela separada."""

    def __init__(
        self,
        app: AutoApp,
        uid: int,
        display_number: int,
        default_key: str = "a",
        default_action: str = "loop",
    ) -> None:
        self.app = app
        self.uid = uid
        self.display_number = display_number
        self.runner = ActionRunner()
        self.captured_key: Key | KeyCode | None = KeyCode.from_char(default_key)
        self.detached = False
        self.float_win: tk.Toplevel | None = None
        self.frame: ttk.Frame | None = None
        self._float_geom: str | None = None
        self._drag_start = None
        self._float_dragging = False
        self._float_drag_job = None
        self._drag_offset_x = 40
        self._drag_offset_y = 20
        self._title_var = tk.StringVar(value=f"Painel {display_number}")

        self.input_mode = tk.StringVar(value="teclado")
        self.action = tk.StringVar(value=default_action)
        self.interval_ms = tk.StringVar(value="100")
        self.press_ms = tk.StringVar(value="50")
        self.mouse_btn = tk.StringVar(value="esquerdo")
        self.key_display = tk.StringVar(value=default_key.upper())
        self.status = tk.StringVar(value="Parado")

        for var in (
            self.input_mode,
            self.action,
            self.interval_ms,
            self.press_ms,
            self.mouse_btn,
        ):
            var.trace_add("write", lambda *_: self.app.schedule_save())

    def set_display_number(self, n: int) -> None:
        self.display_number = n
        self._title_var.set(f"Painel {n}")
        if self.float_win is not None:
            try:
                self.float_win.title(f"Painel {n} — Auto Clicker")
            except Exception:
                pass

    def to_dict(self) -> dict:
        geom = self._float_geom
        if self.detached and self.float_win is not None:
            try:
                geom = self.float_win.geometry()
            except Exception:
                pass
        return {
            "input_mode": self.input_mode.get(),
            "action": self.action.get(),
            "interval_ms": self.interval_ms.get(),
            "press_ms": self.press_ms.get(),
            "mouse_btn": self.mouse_btn.get(),
            "key": serialize_key(self.captured_key),
            "detached": self.detached,
            "geometry": geom,
        }

    def apply_dict(self, data: dict) -> None:
        if data.get("input_mode"):
            self.input_mode.set(data["input_mode"])
        if data.get("action"):
            self.action.set(data["action"])
        if data.get("interval_ms") is not None:
            self.interval_ms.set(str(data["interval_ms"]))
        if data.get("press_ms") is not None:
            self.press_ms.set(str(data["press_ms"]))
        if data.get("mouse_btn"):
            self.mouse_btn.set(data["mouse_btn"])
        key = deserialize_key(data.get("key"))
        if key is not None:
            self.captured_key = key
            self.key_display.set(key_to_label(key))
        self.detached = bool(data.get("detached"))
        self._float_geom = data.get("geometry")

    def destroy_ui(self) -> None:
        self._stop_float_drag()
        if self.float_win is not None:
            try:
                self.float_win.destroy()
            except Exception:
                pass
            self.float_win = None
        if self.frame is not None:
            try:
                self.frame.destroy()
            except Exception:
                pass
            self.frame = None

    def show_docked(self) -> None:
        self._stop_float_drag()
        self.destroy_ui()
        self.detached = False
        self.frame = ttk.Frame(self.app.slots_host, style="Slot.TFrame", padding=12)
        self._build_body(self.frame, floating=False)
        self._refresh_input()
        self._refresh_timing()
        self.refresh_button_label()
        self.app.relayout_docked_slots()
        self.app.schedule_save()

    def show_detached(
        self, restore_geom: str | None = None, continue_drag: bool = False
    ) -> None:
        self.destroy_ui()
        self.detached = True
        win = tk.Toplevel(self.app.root)
        self.float_win = win
        win.title(f"Painel {self.display_number} — Auto Clicker")
        win.configure(bg="#2c3340")
        win.minsize(300, 220)
        win.resizable(True, True)
        geom = restore_geom or self._float_geom or "340x280"
        win.geometry(geom)
        self.frame = ttk.Frame(win, style="Slot.TFrame", padding=12)
        self.frame.pack(fill="both", expand=True)
        self._build_body(self.frame, floating=True)
        self._refresh_input()
        self._refresh_timing()
        self.refresh_button_label()
        # Fechar (X) = remover o painel (não volta para a base)
        win.protocol("WM_DELETE_WINDOW", lambda: self.app.remove_slot(self))
        win.bind("<Configure>", lambda _e: self.app.schedule_save())
        self.app.schedule_save()
        if continue_drag:
            self.app.root.update_idletasks()
            self._start_float_drag()

    def detach_at(self, x: int, y: int, continue_drag: bool = False) -> None:
        if self.detached:
            return
        self._drag_offset_x = 40
        self._drag_offset_y = 20
        self._float_geom = (
            f"340x280+{max(0, x - self._drag_offset_x)}+{max(0, y - self._drag_offset_y)}"
        )
        self.show_detached(restore_geom=self._float_geom, continue_drag=continue_drag)

    def reattach(self, silent: bool = False) -> None:
        self._stop_float_drag()
        if self.float_win is not None:
            try:
                self._float_geom = self.float_win.geometry()
            except Exception:
                pass
        self.show_docked()
        self.app.renumber_slots()
        self.app.relayout_docked_slots()
        if not silent:
            self.app.schedule_save()

    def _start_float_drag(self) -> None:
        """Continua movendo a janela enquanto o botão esquerdo estiver pressionado."""
        self._float_dragging = True
        if self.float_win is not None:
            try:
                self.float_win.lift()
                self.float_win.attributes("-topmost", True)
                self.float_win.after(
                    200, lambda: self.float_win.attributes("-topmost", False)
                    if self.float_win
                    else None
                )
            except Exception:
                pass
        self._poll_float_drag()

    def _stop_float_drag(self) -> None:
        self._float_dragging = False
        job = getattr(self, "_float_drag_job", None)
        if job is not None:
            try:
                self.app.root.after_cancel(job)
            except Exception:
                pass
            self._float_drag_job = None

    def _poll_float_drag(self) -> None:
        if not getattr(self, "_float_dragging", False) or self.float_win is None:
            self._float_dragging = False
            return
        try:
            pressed = bool(ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000)
        except Exception:
            pressed = False
        if not pressed:
            self._stop_float_drag()
            self.app.schedule_save()
            return
        x = self.app.root.winfo_pointerx()
        y = self.app.root.winfo_pointery()
        ox = getattr(self, "_drag_offset_x", 40)
        oy = getattr(self, "_drag_offset_y", 20)
        try:
            self.float_win.geometry(f"+{max(0, x - ox)}+{max(0, y - oy)}")
        except Exception:
            self._stop_float_drag()
            return
        self._float_drag_job = self.app.root.after(16, self._poll_float_drag)

    def _build_body(self, parent: ttk.Frame, floating: bool) -> None:
        top = ttk.Frame(parent, style="Slot.TFrame")
        top.pack(fill="x")

        if not floating:
            grip = ttk.Label(top, text=" ◧ Arrastar ", style="Drag.TLabel", cursor="fleur")
            grip.pack(side="left", padx=(0, 8))
            grip.bind("<ButtonPress-1>", self._on_drag_start)
            grip.bind("<B1-Motion>", self._on_drag_motion)
            grip.bind("<ButtonRelease-1>", self._on_drag_release)

        ttk.Label(top, textvariable=self._title_var, style="SlotTitle.TLabel").pack(
            side="left"
        )

        right = ttk.Frame(top, style="Slot.TFrame")
        right.pack(side="right")
        if floating:
            ttk.Button(right, text="Anexar", command=self.reattach).pack(
                side="left", padx=(0, 6)
            )
        else:
            ttk.Button(right, text="Destacar", command=lambda: self.detach_at(
                self.app.root.winfo_pointerx(), self.app.root.winfo_pointery()
            )).pack(side="left", padx=(0, 6))
        
        ttk.Button(right, text="Remover", command=lambda: self.app.remove_slot(self)).pack(
            side="left"
        )

        mrow = ttk.Frame(parent, style="Slot.TFrame")
        mrow.pack(fill="x", pady=(8, 0))
        ttk.Radiobutton(
            mrow,
            text="Teclado",
            variable=self.input_mode,
            value="teclado",
            style="Slot.TRadiobutton",
            command=self._refresh_input,
        ).pack(side="left", padx=(0, 10))
        ttk.Radiobutton(
            mrow,
            text="Mouse",
            variable=self.input_mode,
            value="mouse",
            style="Slot.TRadiobutton",
            command=self._refresh_input,
        ).pack(side="left")

        self.kb_row = ttk.Frame(parent, style="Slot.TFrame")
        ttk.Label(self.kb_row, text="Tecla:", style="Slot.TLabel").pack(side="left")
        ttk.Entry(
            self.kb_row,
            textvariable=self.key_display,
            width=10,
            state="readonly",
            justify="center",
        ).pack(side="left", padx=6)
        self.capture_btn = ttk.Button(
            self.kb_row,
            text="Capturar",
            command=lambda: self.app.request_slot_key_capture(self),
        )
        self.capture_btn.pack(side="left")

        self.mouse_row = ttk.Frame(parent, style="Slot.TFrame")
        for label, value in (
            ("Esq.", "esquerdo"),
            ("Meio", "meio"),
            ("Dir.", "direito"),
        ):
            ttk.Radiobutton(
                self.mouse_row,
                text=label,
                variable=self.mouse_btn,
                value=value,
                style="Slot.TRadiobutton",
            ).pack(side="left", padx=(0, 8))

        arow = ttk.Frame(parent, style="Slot.TFrame")
        arow.pack(fill="x", pady=(8, 0))
        ttk.Radiobutton(
            arow,
            text="Loop",
            variable=self.action,
            value="loop",
            style="Slot.TRadiobutton",
            command=self._refresh_timing,
        ).pack(side="left", padx=(0, 10))
        ttk.Radiobutton(
            arow,
            text="Segurar",
            variable=self.action,
            value="segurar",
            style="Slot.TRadiobutton",
            command=self._refresh_timing,
        ).pack(side="left")

        self.timing = ttk.Frame(parent, style="Slot.TFrame")
        self.timing.pack(fill="x", pady=(6, 0))
        ttk.Label(self.timing, text="Intervalo ms:", style="Slot.TLabel").pack(
            side="left"
        )
        self.interval_entry = ttk.Entry(
            self.timing, textvariable=self.interval_ms, width=7
        )
        self.interval_entry.pack(side="left", padx=(4, 10))
        ttk.Label(self.timing, text="Pressionado ms:", style="Slot.TLabel").pack(
            side="left"
        )
        self.press_entry = ttk.Entry(self.timing, textvariable=self.press_ms, width=7)
        self.press_entry.pack(side="left", padx=(4, 0))

        ctrl = ttk.Frame(parent, style="Slot.TFrame")
        ctrl.pack(fill="x", pady=(8, 0))
        self.toggle_btn = ttk.Button(ctrl, text="Iniciar", command=self.toggle)
        self.toggle_btn.pack(side="left")
        ttk.Label(ctrl, textvariable=self.status, style="SlotHint.TLabel").pack(
            side="left", padx=10
        )

    def _on_drag_start(self, event) -> None:
        self._drag_start = (event.x_root, event.y_root)

    def _on_drag_motion(self, event) -> None:
        if self._drag_start is None or self.detached:
            return
        dx = abs(event.x_root - self._drag_start[0])
        dy = abs(event.y_root - self._drag_start[1])
        if dx < 40 and dy < 40:
            return
        # Saiu da área da janela principal → destaca
        rx = self.app.root.winfo_rootx()
        ry = self.app.root.winfo_rooty()
        rw = self.app.root.winfo_width()
        rh = self.app.root.winfo_height()
        outside = (
            event.x_root < rx - 8
            or event.y_root < ry - 8
            or event.x_root > rx + rw + 8
            or event.y_root > ry + rh + 8
        )
        if outside or dy > 60 or dx > 80:
            self._drag_start = None
            self.detach_at(event.x_root, event.y_root, continue_drag=True)

    def _on_drag_release(self, _event) -> None:
        self._drag_start = None

    def _refresh_input(self) -> None:
        if self.frame is None:
            return
        self.kb_row.pack_forget()
        self.mouse_row.pack_forget()
        if self.input_mode.get() == "teclado":
            self.kb_row.pack(fill="x", pady=(8, 0))
        else:
            self.mouse_row.pack(fill="x", pady=(8, 0))
        self.app.schedule_save()

    def _refresh_timing(self) -> None:
        if not hasattr(self, "interval_entry"):
            return
        state = "normal" if self.action.get() == "loop" else "disabled"
        self.interval_entry.configure(state=state)
        self.press_entry.configure(state=state)
        self.app.schedule_save()

    def set_capture_enabled(self, enabled: bool) -> None:
        if hasattr(self, "capture_btn") and self.capture_btn.winfo_exists():
            self.capture_btn.configure(state="normal" if enabled else "disabled")

    def set_key(self, key) -> None:
        self.captured_key = key
        self.key_display.set(key_to_label(key))
        self.status.set("Parado")
        self.app.schedule_save()

    def refresh_button_label(self) -> None:
        if not hasattr(self, "toggle_btn"):
            return
        try:
            if not self.toggle_btn.winfo_exists():
                return
        except Exception:
            return
        if self.runner.running:
            self.toggle_btn.configure(text="Parar")
            self.status.set("Em execução")
        else:
            self.toggle_btn.configure(text="Iniciar")
            if self.status.get() != "Aguardando tecla...":
                self.status.set("Parado")

    def toggle(self) -> None:
        if self.runner.running:
            self.stop()
        else:
            err = self.start()
            if err:
                messagebox.showerror("Erro", err)

    def start(self) -> str | None:
        if self.runner.running:
            return None
        if self.app._capture_target is not None:
            return "Termine a captura de tecla primeiro."
        try:
            interval = press = 0.0
            if self.action.get() == "loop":
                interval = parse_ms(self.interval_ms.get(), "intervalo")
                press = parse_ms(self.press_ms.get(), "tempo pressionado", 0)
        except ValueError as exc:
            return str(exc)
        if self.input_mode.get() == "teclado" and self.captured_key is None:
            return "Capture uma tecla."
        if (
            self.input_mode.get() == "teclado"
            and self.action.get() == "segurar"
            and keys_equal(self.captured_key, self.app.hotkey)
        ):
            return "Tecla de ação igual ao atalho global."

        self.runner.start(
            input_mode=self.input_mode.get(),
            action=self.action.get(),
            key=self.captured_key,
            mouse_btn=self.mouse_btn.get(),
            interval=interval,
            press_duration=press,
            on_error=lambda e: self.app.root.after(
                0, lambda: messagebox.showerror("Erro", e)
            ),
            on_stopped=lambda: self.app.root.after(0, self.refresh_button_label),
        )
        self.refresh_button_label()
        return None

    def stop(self) -> None:
        self.runner.stop()
        self.refresh_button_label()


def main() -> None:
    root = tk.Tk()
    root.update_idletasks()
    w, h = 520, 620
    x = (root.winfo_screenwidth() - w) // 2
    y = (root.winfo_screenheight() - h) // 2
    root.geometry(f"{w}x{h}+{x}+{y}")
    AutoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
