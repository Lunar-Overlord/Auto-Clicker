@echo off
cd /d "%~dp0"

set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" -m pip install -r requirements.txt -q
"%PY%" app.py
if errorlevel 1 pause
